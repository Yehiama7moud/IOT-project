import 'package:flutter/material.dart';
import 'package:flutter_application_1/TrafficApp/mqtt_service.dart';


class Control extends StatefulWidget {
  const Control({super.key});

  @override
  State<Control> createState() => _ControlPage();
}

class _ControlPage extends State<Control> {
  final MqttService mqttService = MqttService();// Instance of MQTT service to handle communication

  bool gateSwitchValue = true;// Controls gate open/close
  bool nightMode = true; // Controls street light mode
  String selectedTrafficState = 'GREEN';// Controls traffic light state


  
  String incomingMessage = '';// Stores incoming MQTT messages


  @override
  void initState() {
    super.initState();
    mqttService.onMessageReceived = (message) {// Set up callback to handle incoming MQTT messages
      setState(() {
        incomingMessage = message;
      });
    };
    mqttService.initialize();// Initialize MQTT connection
    
  }



  void onChangedGate(bool newValue) {// Called when gate switch is toggled
    setState(() {
      gateSwitchValue = newValue;
    });
    mqttService.publish('trafficApp/gate', newValue ? 'OPEN' : 'CLOSE');// Publish gate status to MQTT topic
   
  }

  void onChangedNight(bool newValue) {// Called when night mode switch is toggled
    setState(() {
      nightMode = newValue;
    });
    mqttService.publish('trafficApp/light', newValue ? 'NIGHT' : 'DAY');// Publish light mode to MQTT topic
     
  }

  void onChangedTraffic(String? newValue) {// Clled when traffic light dropdown value changes
    if (newValue != null) {
      setState(() {
        selectedTrafficState = newValue;
      });
      mqttService.publish('trafficApp/traffic', selectedTrafficState);      // Publish traffic light status to MQTT topic

     
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
                        // Gate Control Section
            const Text("Gate Control", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Container(//Container: Wraps the gate control UI with padding and background color
              color: Colors.white,// Background color of the container
              //width: double.infinity,
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              child: Row(//Row: Lays out the switch and label horizontally

                children: [
                  Switch.adaptive(//Switch Widget: Toggles gate open/close

                    value: gateSwitchValue,// Current state of the switch (true = open)
                    onChanged: onChangedGate,// Callback when switch is toggled
                    activeTrackColor: const Color(0xFF427777),
                  ),
                  const SizedBox(width: 20),
                  const Text("OPEN GATE", style: TextStyle(fontSize: 16)),
                ],
              ),
            ),
            const SizedBox(height: 20),// Adds spacing between switch and text
            const Text("Street Light Control", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Container(
              color: Colors.white,
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Switch.adaptive(
                    value: nightMode,
                    onChanged: onChangedNight,
                    activeTrackColor: const Color(0xFF427777),
                  ),
                  const SizedBox(width: 20),
                  const Text("NIGHT MODE ON", style: TextStyle(fontSize: 16)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text("Traffic Status Control", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            Container(
              color: Colors.white,
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  const Icon(Icons.traffic_outlined, size: 24),
                  const SizedBox(width: 20),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Traffic Manual Control", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                      DropdownButton<String>( //Dropdown: Allows user to select traffic light status
                        value: selectedTrafficState,// Current selected value
                        items: ['RED', 'YELLOW', 'GREEN'].map((String value) {// Maps each string to a dropdown item
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value, style: const TextStyle(fontSize: 14)),
                          );
                        }).toList(),// Converts mapped items to a list
                        onChanged: onChangedTraffic,// Callback when selection changes
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';//import supabase flutter for realtime data streaming


// Define a stateful widget to display live traffic status
class LiveStatus extends StatefulWidget{
  const LiveStatus({super.key});

  @override
  State<LiveStatus> createState() => _LiveStatusPage();
}
// Define the state class for LiveStatus hold state of widgets
class _LiveStatusPage extends State<LiveStatus> {
  // Initialize Supabase client
  final supabase = Supabase.instance.client;

// Define real-time streams for database tables
  late final gateStatusStream = supabase.from('gate_status').stream(primaryKey: ['id']).order('updated_at',ascending: false);// Latest gate status first
  late final TrafficStatusStream = supabase.from('traffic_lights').stream(primaryKey: ['id']);
  late final StreetLightStatusStream = supabase.from('street_lights').stream(primaryKey: ['id']);
  late final ViolationStream = supabase.from('violations').stream(primaryKey: ['id']);

   // Variables to hold live data
  String gateStatus='loading';
  String trafficLight='Loading';
  int carViolation=0;
  String countDown='Loading';

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width; // Get screen width for responsive layout

    return Scaffold(
      body:SingleChildScrollView(
        child: Column(
          
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          spacing: 10,
          children: [
            const SizedBox(height: 5),
             // Section: Traffic Light Status
            Text("   Current Traffic Light",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
            Container( //Current Traffic light
            color: Colors.white,
            width: screenWidth * 0.9,
            padding: EdgeInsets.all(screenWidth * 0.05),
            child: Row(
            spacing: 30,
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(Icons.traffic_outlined,size:24),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Current Traffic Light",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
                  StreamBuilder(// StreamBuilder to listen for traffic light updates
                    stream: TrafficStatusStream //listens to of data (trafficStatusStream) which is connected to traffic_light in database
                  , builder: (context,snapshot){// snapshot contains the latest data from the stream, and it updates automatically when new data arrives.
                    if(snapshot.connectionState == ConnectionState.waiting){//- While the stream is still connecting or waiting for data "Loading" message appear.
                      return Text('Loading');
                    }else if(snapshot.hasError){//- If something goes wrong, it shows "error".
                      return Text('error');
                    }else if(!snapshot.hasData){//- If the stream is connected but there’s no data in the table, it shows a no data available  message.
                      return Text('No data available in table');
                    }else{//if data is available
                      final latestStatus =snapshot.data!.first;//grabs first row
                      trafficLight=latestStatus['status'];//extracts status (traffic light color)
                      return Text(trafficLight,style: TextStyle(fontWeight:FontWeight.normal,fontSize: 14));//dispaly text
                    }
                  })
                ],
              )
            ],
            ),
            ),
            const SizedBox(height: 5),
            //Gate Status 
            Text("   Gate Status",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
            Container(//Gate status
            color: Colors.white,
            width: screenWidth * 0.9,
            padding: EdgeInsets.all(screenWidth * 0.05),
            child: Row(
            spacing: 30,
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(Icons.door_sliding,size:24),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Gate Status",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
                  StreamBuilder(// StreamBuilder to listen for gate status updates
                    stream: gateStatusStream,//listens to of data (gateStatusStream) which is connected to gate_status in database
                    builder: (context,snapshot){//snapshot is latest data from stream
                    if(snapshot.connectionState == ConnectionState.waiting){//waiting till connecting while displaying loading message
                      return Text('Loading');
                    }else if(snapshot.hasError){//if error occur send error message
                      return Text('error');
                    }else if(!snapshot.hasData){//if no data available in yable display amessage
                      return Text('No data available in table');
                    }else{
                      final latestStatus =snapshot.data!.first;//grabs first row
                      gateStatus=latestStatus['status'];//extract status open or closed
                      return Text(gateStatus,style: TextStyle(fontWeight:FontWeight.normal,fontSize: 14));//display status
                    }
                  })
                ],
              )
            ],
            ),
            ),
            const SizedBox(height: 5),
            //last countdown timer in database
            Text("   Timer",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
            Container(
            color: Colors.white,
            width: screenWidth * 0.9,
            padding: EdgeInsets.all(screenWidth * 0.05),
            child: Row(
            spacing: 30,
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(Icons.timer_sharp,size:24),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Timer",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
          
                  StreamBuilder(//streambuilder to listen for timer changes 
                    stream: TrafficStatusStream //stream data is aTrafficStatusSystem(streams from traffic_lights table in database)
                    , builder: (context,snapshot){
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Text('Loading');
                    }else if(snapshot.hasError){
                      return Text('error');
                    }else if(!snapshot.hasData){
                      return Text('No data available in table');
                    }else{
                      final latestStatus =snapshot.data!.first;
                      countDown=latestStatus['countdown'].toString();;//takes latest countdown and convert it to string to be displayes
                      return Text(countDown,style: TextStyle(fontWeight:FontWeight.normal,fontSize: 14));
                    }
                  })
                  
                ],
              )
            ],
            ),
            ),
             const SizedBox(height: 5),
             //violation count
            Text("   Car Violation Count",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
            Container(
              color: Colors.white,
             width: screenWidth * 0.9,
            padding: EdgeInsets.all(screenWidth * 0.05),
            child: Row(
            spacing: 30,
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(Icons.car_crash,size:24),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Car Violation Count",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
                  StreamBuilder(//stream builder to count car violations
                    stream: ViolationStream,//ViolationStream listens from violations table in database 
                    builder: (context,snapshot){
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Text('Loading');
                    }else if(snapshot.hasError){
                      return Text('error');
                    }else if(!snapshot.hasData){
                      return Text('No data available in table');
                    }else{
                       final trueDetections = snapshot.data!.where((row) => row['car_detected'] == true).toList();//filters list of rows to keep only rows where car detected is  equal true and converts filtired result back into a list 
                       final count = trueDetections.length;//lenght means how many car detected 
                       carViolation=count;
                         return Text(carViolation.toString(),style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold), );

                    }
                  })
                  
                ],
              )
            ],
            ),
            ),
          ],
        ),
      )
      )
    ;
  }
}
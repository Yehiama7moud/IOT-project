import 'package:flutter/material.dart';
import 'package:flutter_application_1/TrafficApp/HomePage.dart';
import 'package:flutter_application_1/TrafficApp/auth_service.dart';
import 'package:form_field_validator/form_field_validator.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginpageState();
}

class _LoginpageState extends State<LoginPage> {
  
  late final AuthService _authService = AuthService();// Initialize AuthService to handle sign-in and sign-up

  

  // Key to manage the form state
  final _formkey = GlobalKey<FormState>();

  // Controllers to capture input
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(//AppBar with custom styling

        toolbarHeight: 150,
        backgroundColor: const Color.fromARGB(255, 66, 119, 119),
        title: Text(
          "Traffic Smart System",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 30,
            fontStyle: FontStyle.italic,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 30.0),
                child: Center(
                  child: Container(//car icon inside a styled container
                    width: 120,
                    height: 120,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                      border: Border.all(color: Color.fromARGB(255, 66, 119, 119)),
                    ),
                    child: Icon(Icons.directions_car, size: 100),
                  ),
                ),
              ),
              Padding(//Form section with email and password fields
                padding: EdgeInsets.symmetric(horizontal: 15),
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Form(
                    key: _formkey,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: TextFormField(
                            controller: emailController,
                            validator: MultiValidator([
                              RequiredValidator(errorText: "Enter Email address"),
                              EmailValidator(errorText: "Please Enter Correct Email"),
                            ]).call,
                            decoration: InputDecoration(
                              hintText: 'Email',
                              labelText: 'Email',
                              prefixIcon: Icon(Icons.email),
                              errorStyle: TextStyle(fontSize: 18.0),
                              border: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.red),
                                borderRadius: BorderRadius.all(Radius.circular(9.0)),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: TextFormField(
                            controller: passwordController,
                            obscureText: true, // Hides password input
                            validator: MultiValidator([
                              RequiredValidator(errorText: 'Please Enter Password'),
                              MinLengthValidator(8, errorText: 'Password Must be \nat Least 8 characters'),
                              PatternValidator(r'(?=.*?[#!@$%^&*-])',
                                  errorText: 'Password Must Have At Least \nOne Special Character'),
                            ]).call,
                            decoration: InputDecoration(
                              hintText: 'Password',
                              labelText: 'Password',
                              prefixIcon: Icon(Icons.key),
                              errorStyle: TextStyle(fontSize: 18.0),
                              border: OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.red),
                                borderRadius: BorderRadius.all(Radius.circular(9.0)),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(12.0),
                child: ElevatedButton(//Sign Up Button
                  onPressed: () async{
                    if (_formkey.currentState!.validate()) {
                     final email = emailController.text;
                     final password = passwordController.text;

                    try {
                      final response = await _authService.signUpWithEmailPassword(email, password);
                      if (response.user != null) {
                         ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Account Created Successfully')),
                      );
                    }
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                     SnackBar(content: Text('Sign Up Failed: ${e.toString()}')),
                    );
                  }
  
                    }
                
                    
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 66, 119, 119),
                    foregroundColor: Colors.white,
                  ),
                  child: Text('Sign In', style: TextStyle(color: Colors.white, fontSize: 22)),
                ),
              ),
              Padding(//Login Button
                padding: const EdgeInsets.all(12.0),
                child: ElevatedButton(
               onPressed: () async {
                if (_formkey.currentState!.validate()) {
                     final email = emailController.text;
                     final password = passwordController.text;

                  try {
                    final response = await _authService.signInWithEmailPassword(email, password);
                    if (response.session != null) {
                    Navigator.push(
                    context,
                  MaterialPageRoute(builder: (context) => Homepage()),
                  );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Invalid Email or Password')),
                  );
                }
               } catch (e) {
                 ScaffoldMessenger.of(context).showSnackBar(
                 SnackBar(content: Text('Login Failed: ${e.toString()}')),
                );
    }
  }
},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color.fromARGB(255, 66, 119, 119),
                    foregroundColor: Colors.white,
                  ),
                  child: Text('Login', style: TextStyle(color: Colors.white, fontSize: 22)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
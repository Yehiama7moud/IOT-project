import 'package:flutter/material.dart'; 
import 'package:flutter_application_1/TrafficApp/Interface.dart'; //import splash screen
import 'package:supabase_flutter/supabase_flutter.dart';// supabase flutter package for integration with supabase

//supabase credintials 
String URL='https://ufrtmaqbbssewzieonnq.supabase.co'; // supabase project url
String annon_key='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVmcnRtYXFiYnNzZXd6aWVvbm5xIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU2MjcyNjAsImV4cCI6MjA3MTIwMzI2MH0.m1Z5cLZlAau1VYpEgcAsBVnyMbDqBUkI0M-CyTW0ODk';
//annon_key is public anonymous API key for accessing Supabase services





void main() async {//main entry point of application
  WidgetsFlutterBinding.ensureInitialized(); //ensure widgets are initialized before running asynchronus code
  await Supabase.initialize(anonKey:annon_key,url:URL );//initialize supabase
  runApp(const TrafficApp());// Launch the TrafficApp widget as the root of the application(first to get loaded and displayed)

}

class TrafficApp extends StatelessWidget {
  const TrafficApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,// Disable the debug banner
      home: const Interface(), //       // Set the initial screen to the Interface widget and load it
    );
  }
}

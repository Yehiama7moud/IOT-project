import 'package:flutter/material.dart';
import 'package:flutter_application_1/TrafficApp/login_page.dart';//import login page
// Define a stateless widget called Interface (splash screen)
class Interface extends StatelessWidget {
  const Interface ({super.key});
  @override
  Widget build(BuildContext context) {
    // Schedule a task to run after a 5-second delay
    // This navigates to the LoginPage and replaces the current screen
    Future.delayed(const Duration(seconds: 5), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) =>  LoginPage()),
      );
    });
    return Scaffold(
      backgroundColor: const Color.fromARGB(255, 66, 119, 119),//set background color
      body: Center(// Center the content vertically and horizontally
        child: Column(// Used a Column to arrange widgets vertically
          mainAxisAlignment: MainAxisAlignment.center,// Center the children vertically within the column
          children: [
            // Display large car icon 
            Icon(
              Icons.directions_car,
              size: 200,
              color: Colors.black,
            ),
            const SizedBox(height: 20), // Add vertical spacing between the icon and the text
            const Text(// Display the app title
              "Traffic Smart System",// App name
              style: TextStyle(
                fontWeight: FontWeight.bold,//bold text
                fontSize: 35,//large font size
                fontStyle: FontStyle.italic,//itallic style
                color: Colors.black,//vlack text color
              ),
            ),
          ],
        ),
      ),
    );
  }
}
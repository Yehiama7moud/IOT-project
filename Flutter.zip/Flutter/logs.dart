import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';



class Logs extends StatefulWidget{
  const Logs({super.key});

  @override
  State<Logs> createState() => _LogsPage();
}

class  _LogsPage extends State<Logs> {
  final supabase = Supabase.instance.client;
  late final violationStream = supabase.from('violations').stream(primaryKey: ['id']).order('violation_time',ascending: false);//Stream for traffic violations, ordered by most recent

  late final trafficStatusStream = supabase  //  Stream for general traffic status from a view, limited to 100 entries
  .from('combined_status_view')
  .stream(primaryKey: ['timestamp'])
  .order('timestamp', ascending: false).limit(100);

  

   
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:SingleChildScrollView(//Allows vertical scrolling

        
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.max,
          //spacing: 10,
          children: [
            const SizedBox(height: 5),
            Text("   Traffic Violation History",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
            StreamBuilder(//StreamBuilder to listen for violation updates

              stream: violationStream,
              builder: (context, snapshot) {
                 if (snapshot.connectionState == ConnectionState.waiting) {
                        return CircularProgressIndicator();//loading indicator
                   } else if (snapshot.hasError) {
                        return Text('Error loading data ${snapshot.error}');
                   }else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                        return Text('No violations found');
                      }
                    // Map each row to a DataRow for the DataTable

                    final rows = snapshot.data!.map((row) {
                     return DataRow(cells: [
                     DataCell(Text(row['violation_time'].toString())),
                     DataCell(Text(row['night_mode'].toString())),
                     DataCell(Text(row['car_detected'].toString())),
                    ]);
                    }).toList();
                return SingleChildScrollView(//Horizontal scrollable DataTable for traffic status

                  scrollDirection: Axis.horizontal,
                  child:  ConstrainedBox(
                        constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width),
                        child: DataTable(//violation history table
                        headingRowColor: WidgetStateProperty.all<Color>(const Color.fromARGB(255, 66, 119, 119)),
                        dividerThickness: 5,
                          columns:[
                            DataColumn(label: Text('Time')),
                            DataColumn(label: Text('Night Mode')),
                            DataColumn(label: Text('Car detect')),
                            ] , 
                          rows: rows),
                      )
                    
                  
                );
              }
            ),
            const SizedBox(height: 5),
            Text("   General Traffic Status",style: TextStyle(fontWeight:FontWeight.bold,fontSize: 18),),
                 StreamBuilder(
                   stream: trafficStatusStream,
                   builder: (context, snapshot) {
                     if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                } else if (snapshot.hasError) {
                  return Text('Error loading traffic status ${snapshot.error}');
                } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Text('No traffic status found');
                }

                    final rows = snapshot.data!.map((row) {
                    return DataRow(cells: [
                    DataCell(Text(row['timestamp'].toString())),
                    DataCell(Text(row['street_light_status'].toString())),
                     DataCell(Text(row['gate_status'].toString())),
                     DataCell(Text(row['traffic_light_status'].toString())),
                     ]);
                    }).toList();

                     return SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      
                      child: ConstrainedBox(
                      constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width + 100),
                      child: DataTable(//General tarfic status table
                      headingRowColor: WidgetStateProperty.all<Color>(const Color.fromARGB(255, 66, 119, 119)),
                      dividerThickness: 5,
                      columns:[
                            DataColumn(label: Text('Time')),
                            DataColumn(label: Text('Night/Day Mode')),
                            DataColumn(label: Text('Gate Status')),
                            DataColumn(label: Text("Traffic Status"))
                            ] , 
                      rows:rows ),
                               )
                                     );
                   }
                 )
              
          
          ],
    )
    )
    );
  }
}
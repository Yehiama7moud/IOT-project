// Import Dart's IO library for secure socket handling
import 'dart:io';
// Import MQTT client libraries
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

// Define a service class to manage MQTT communication
class MqttService {
  final String serverUri = 'db214e9cf2184882a22e1639d81e429f.s1.eu.hivemq.cloud'; // HiveMQ Cloud broker URL
  final int port = 8883; // Secure MQTT port
  final String clientIdentifier = 'sharedClient'; // Unique client ID
  final String username = 'Hania'; //MQTT username
  final String password = '5566mLKs'; // MQTT password


  late MqttServerClient client;// MQTT client instance
  bool isConnected = false; // Tracks connection status

  Function(String)? onMessageReceived;// Optional9nullable) callback to handle incoming messages


  Future<void> initialize() async {  // Initializes the MQTT client and connects to the broker

    client = MqttServerClient.withPort(serverUri, clientIdentifier, port);    // Create the client with server URI, client ID, and port
    // Enable secure connection using TLS
    client.secure = true;
    client.securityContext = SecurityContext.defaultContext;
    // Enable logging for debugging
    client.logging(on: true);
    client.keepAlivePeriod = 20;// Set keep-alive interval in seconds(If no data is sent during that time, the client sends a small "ping" to let the server know it's still connected.)

    
    client.onConnected = () {    // Callback when connection is successful
      isConnected = true;
      client.subscribe('trafficApp/#', MqttQos.atMostOnce);// Subscribe to all topics under trafficApp
    };

    client.onDisconnected = () {// Callback when disconnected from broker
      isConnected = false;
    };

    client.onSubscribed = (topic) {// Callback when a topic is successfully subscribed
      print('Subscribed to $topic');
    };
    /*client.updates is a stream of incoming mqtt messages , ?.listen() is if updates not null start listening ,call back recives a list of messages*/ 
    client.updates?.listen((List<MqttReceivedMessage<MqttMessage>> messages) {
      final recMessage = messages[0].payload as MqttPublishMessage;//extract first published message 
      final payload = //converts payload (mqtt messages sent as bytes) toMqttPublishMesssage (a string with readable format)
          MqttPublishPayload.bytesToStringAsString(recMessage.payload.message);
      if (onMessageReceived != null) {// If a message handler is defined, call it with the payload
        onMessageReceived!(payload);
      }
    });
         // Build the connection message with authentication and QoS settings
    final connMess = MqttConnectMessage()
        .withClientIdentifier(clientIdentifier)
        .authenticateAs(username, password)
        .startClean() // Start a new session
        .withWillQos(MqttQos.atMostOnce);//set level of guarantee for message deleivert between a publisher abd subscriber to 0 level(at most once) no guarntee
      client.connectionMessage = connMess;//client.connectionMessage = connMess;

    try {
      await client.connect();// Attempt to connect to the broker
    } catch (e) {
      print('MQTT connection error: $e');// Print error and disconnect if connection fails
      client.disconnect();
    }
  }
  // Publishes a message to a specific topic
  void publish(String topic, String message) {
    if (isConnected) {// Only publish if connected to the broker
      final builder = MqttClientPayloadBuilder(); // Build the message payload
      builder.addString(message);
      client.publishMessage(topic, MqttQos.atMostOnce, builder.payload!);// Publish the message with QoS level 0
    } else {
      print('Cannot publish, not connected');// Print warning if not connected
    }
  }
  
}
import 'package:flutter/material.dart';
import 'package:flutter_application_1/TrafficApp/control.dart';
import 'package:flutter_application_1/TrafficApp/liveStatus.dart';
import 'package:flutter_application_1/TrafficApp/logs.dart';


class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomePageState();
}

class _HomePageState extends State<Homepage> {
  int _selectedIndex = 0;// Keeps track of which bottom navigation item is selected

  void _navigateBottomBar(int index) {  // Updates the selected index when a bottom nav item is tapped
    setState(() {
      _selectedIndex = index;
    });
  }
  // List of pages to display based on selected index
  final List<Widget> _pages = [LiveStatus(), Control(), Logs()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: const Color.fromARGB(255, 66, 119, 119),
        title: Text(
          "Traffic Smart System",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 30,
            fontStyle: FontStyle.italic,
            color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      
      body: _pages[_selectedIndex],//Displays the selected page from the bottom navigation
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,// Highlights the selected item
        onTap: _navigateBottomBar,// Handles tap events
        selectedItemColor: Color.fromARGB(255, 66, 119, 119), // Custom color
        selectedIconTheme: IconThemeData(color: Color.fromARGB(255, 66, 119, 119)),// Icon color
        items: [// Navigation items
          BottomNavigationBarItem(icon: Icon(Icons.podcasts), label: "Live Status"),
          BottomNavigationBarItem(icon: Icon(Icons.tune), label: "Control"),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: "Logs"),
        ],
      ),
    );
  }
}